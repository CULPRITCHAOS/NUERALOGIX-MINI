

import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  base: './', // Enables relative asset paths for deployment to subdirectories (e.g. GitHub Pages)
})